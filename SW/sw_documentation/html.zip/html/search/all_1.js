var searchData=
[
  ['calibratetorque',['calibrateTorque',['../classServoRHA.html#a2b85e528b987d734d4b99613b49c594c',1,'ServoRHA']]],
  ['calibratetorquedir',['calibrateTorqueDir',['../classServoRHA.html#a2faeef2bb525c57171905d7390cfa1c9',1,'ServoRHA']]],
  ['checkspeed',['checkSpeed',['../utilities_8h.html#ae72b9214473e4a5ed0412610022f66c7',1,'MeasureUtilities']]],
  ['checktimegetinfo',['checkTimeGetInfo',['../utilities_8h.html#adc30c6f58357daa7118ee380139c1f3a',1,'MeasureUtilities']]],
  ['checktimespeedread',['checkTimeSpeedRead',['../utilities_8h.html#abd65879a27a358d108d3d2bf61dbbc85',1,'MeasureUtilities']]],
  ['compareangles',['compareAngles',['../servo__rha_8cpp.html#a423942587cd078cd1dc677829e34cb18',1,'compareAngles(uint16_t angle1, uint16_t angle2, uint8_t angle_margin):&#160;servo_rha.cpp'],['../servo__rha_8h.html#a0b13d12e2309c13a3c7fc3857aa25db4',1,'compareAngles(uint16_t angle1, uint16_t angle2, uint8_t angle_margin=0):&#160;servo_rha.cpp']]],
  ['comparespeed',['compareSpeed',['../servo__rha_8cpp.html#ac74e39c3dac1d2fc9ff05f10fb898042',1,'compareSpeed(uint16_t speed1, uint16_t speed2, uint8_t speed_margin):&#160;servo_rha.cpp'],['../servo__rha_8h.html#a83a3d81c41c917fcbfa97c3d4e0877a5',1,'compareSpeed(uint16_t speed1, uint16_t speed2, uint8_t speed_margin=0):&#160;servo_rha.cpp']]],
  ['controlloop',['controlLoop',['../classJointHandler.html#a1f890b1331990499e0c7b5a9fb3040cf',1,'JointHandler']]],
  ['cytron_5fg15_5fservo',['Cytron_G15_Servo',['../classCytron__G15__Servo.html',1,'']]]
];
