var searchData=
[
  ['calculatetorque',['calculateTorque',['../classServoRHA.html#a55f17134923b3cdba89e08794d240336',1,'ServoRHA']]],
  ['checkcomsucces',['checkComSucces',['../classJHUtilitiesJH.html#a708939a7f00508e7b793c56ceca4e7b1',1,'JHUtilitiesJH']]],
  ['checkconectionall',['checkConectionAll',['../classJointHandler.html#accde2d403ce4493a53192b2a0e9ce6a2',1,'JointHandler']]],
  ['checkcontinue',['checkContinue',['../classRHATypes_1_1Timer.html#a0d2a82909a9af9947b222ed5b3b8ea07',1,'RHATypes::Timer::checkContinue()'],['../classRHATypes_1_1TimerMicroseconds.html#a3394628ac96864eb3204efde4efd80fc',1,'RHATypes::TimerMicroseconds::checkContinue()']]],
  ['checkspeed',['checkSpeed',['../classJHUtilitiesJH.html#adeb7da119b1cfd66ed35ca6f0c5c1ee8',1,'JHUtilitiesJH']]],
  ['checktimegetinfo',['checkTimeGetInfo',['../classJHUtilitiesJH.html#a05d87d55b26eefe9cca542498b43a68e',1,'JHUtilitiesJH']]],
  ['checkwait',['checkWait',['../classRHATypes_1_1Timer.html#ad4b4d5aa5fb45044ee3370d8e56e1e3f',1,'RHATypes::Timer::checkWait()'],['../classRHATypes_1_1TimerMicroseconds.html#a59a756d5b4643c33b3be2f02a8b7743f',1,'RHATypes::TimerMicroseconds::checkWait()']]],
  ['compareangles',['compareAngles',['../servo__rha_8cpp.html#a423942587cd078cd1dc677829e34cb18',1,'compareAngles(uint16_t angle1, uint16_t angle2, uint8_t angle_margin):&#160;servo_rha.cpp'],['../servo__rha_8h.html#a0b13d12e2309c13a3c7fc3857aa25db4',1,'compareAngles(uint16_t angle1, uint16_t angle2, uint8_t angle_margin=0):&#160;servo_rha.cpp']]],
  ['comparespeed',['compareSpeed',['../servo__rha_8cpp.html#ac74e39c3dac1d2fc9ff05f10fb898042',1,'compareSpeed(uint16_t speed1, uint16_t speed2, uint8_t speed_margin):&#160;servo_rha.cpp'],['../servo__rha_8h.html#a83a3d81c41c917fcbfa97c3d4e0877a5',1,'compareSpeed(uint16_t speed1, uint16_t speed2, uint8_t speed_margin=0):&#160;servo_rha.cpp']]],
  ['controlloop',['controlLoop',['../classJointHandler.html#a1f890b1331990499e0c7b5a9fb3040cf',1,'JointHandler']]]
];
