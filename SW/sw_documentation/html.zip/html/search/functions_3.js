var searchData=
[
  ['init',['init',['../classJointRHA.html#acf5dd56eb854250047a9ee2d0a402e4f',1,'JointRHA::init()'],['../classServoRHA.html#a3cc8f36d2756e5a196ec13e12f1a2286',1,'ServoRHA::init(uint8_t servo_id, uint8_t rxpin, uint8_t txpin, uint8_t ctrlpin, uint32_t baudrate)'],['../classServoRHA.html#abd64398a4d18799952561bd7a5ded082',1,'ServoRHA::init()']]],
  ['ismoving',['isMoving',['../classServoRHA.html#a6935a684c935c92c255a96f51eb3c39d',1,'ServoRHA']]]
];
