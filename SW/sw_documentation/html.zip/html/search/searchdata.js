var indexSectionsWithContent =
{
  0: "acdeijkmprsuw~",
  1: "cjs",
  2: "djsu",
  3: "aceijprsuw~",
  4: "adkm",
  5: "er"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Macros",
  5: "Modules"
};

